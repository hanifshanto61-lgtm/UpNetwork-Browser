# UpNetwork Browser — Android + Windows Source Project

A Chromium-based browser-profile manager starter project with a Windows desktop engine and an Android WebView client.

## Architecture status

See `docs/architecture/MASTER-ARCHITECTURE.md` and `shared-core-profile-schema.json` for the cross-platform profile contract and staged implementation plan. The schema is a design contract; it does not by itself add Android per-profile browser isolation.

## What is included

### Windows
- Electron desktop application.
- Playwright-managed Chromium persistent contexts.
- Create, edit, launch, close and delete profiles.
- Per-profile user-data directories (cookies, local storage and cache).
- Proxy configuration for HTTP/HTTPS/SOCKS5 endpoints supported by Playwright.
- User-Agent, locale, timezone and viewport configuration.
- Pre-launch checks using the configured profile context:
  - navigation / proxy connectivity
  - observed public IP and IP geolocation
  - configured User-Agent
  - browser-reported language and timezone
  - WebRTC diagnostic test page link
- PASS / WARNING / FAIL report; required checks gate the visible browser launch.
- JSON profile store; no account credentials are collected.

### Android
- Kotlin Android app using Android System WebView (Chromium-based).
- Create and save profile configurations.
- Configure User-Agent, proxy endpoint, locale, timezone and viewport notes.
- Open a browser tab and run basic IP / User-Agent / language / timezone diagnostics.
- Exportable profile report in the UI.

## Important platform limitations

This is a working source foundation, not a claim of feature parity with GoLogin, AdsPower or Roxy.

1. **Android WebView is Chromium-based, but is not a separately bundled full Chromium build.** Android WebView is updated by the Android system/WebView provider.
2. Android WebView's supported proxy APIs vary by Android version and WebView provider. This starter intentionally does not silently claim proxy support where the API is unavailable. The Android screen reports this limitation.
3. Android WebView does not provide a supported API for arbitrary per-profile independent browser processes/data directories at unlimited scale. The included Android client stores profile settings, but true concurrent isolated Android profiles require a custom Chromium build or a different engine architecture. Do not treat its profiles as isolated anti-detect identities.
4. Changing User-Agent, locale, timezone or viewport does **not** make a browser undetectable or guarantee a site's acceptance. This app does not spoof Canvas/WebGL/audio fingerprints, bypass CAPTCHAs, evade platform security, or guarantee account separation.
5. IP geolocation is approximate. A successful IP check does not prove that every site sees the same network route.
6. WebRTC/DNS checks are diagnostics, not a guarantee of zero leaks.

## Requirements

- Windows 10/11, Node.js 20+ and npm.
- Android Studio Hedgehog or newer, JDK 17, Android SDK 35.
- Internet connection for initial Chromium download and IP checks.

## Run Windows app

```bash
cd desktop
npm install
npx playwright install chromium
npm start
```

To package a Windows installer:

```bash
npm run dist:win
```

The installer is produced only after a successful local build. It is not included in this source ZIP.

## Open Android project

Open the `android` directory in Android Studio, allow Gradle sync, then run the `app` configuration on an Android device/emulator.

## Profile storage

Windows profile data is stored under Electron's user data directory in `profiles/`. Deleting a profile from the UI closes it and removes its profile directory after confirmation. Back up important data first.

Android profile definitions are stored in app-private preferences. Android WebView data is app-wide in this starter, not truly isolated per profile.

## Security notes

- Use only proxies and accounts you are authorized to use.
- Do not put proxy passwords or private tokens in screenshots or support logs.
- Profile JSON is stored locally. Protect the Windows user account and Android device.
- This project has not been security-audited or certified for production use.
