# UpNetwork Browser — Master Architecture (Foundation v1)

## Product target
One profile-management product for Android and Windows. “Unlimited profiles” means no artificial product-level cap; actual concurrent sessions are limited by device RAM, storage, OS and browser-engine constraints.

## Platform engines
- Windows: Electron UI + Playwright persistent Chromium contexts in a unique user-data directory per profile. This is the current runnable desktop foundation.
- Android: Kotlin UI + Android System WebView in the current starter. Android WebView data is app-wide in this starter; profile records are configuration only. Do not advertise them as isolated browser identities.
- Future Android isolation milestone: evaluate a maintained Chromium-derived Android engine with supported independent profile/data-directory boundaries. This is a separate engineering project and must pass storage-isolation, process, update and security tests before being enabled.

## Shared profile contract
`shared-core-profile-schema.json` defines the cross-platform profile record. Each record has a stable ID and storageKey. Proxy credentials must be stored in OS secure storage; profile JSON stores references only. Never log proxy passwords.

## Storage rules
- Windows: `profiles/<profile-id>/` is the persistent Chromium user-data directory. Never reuse it for another profile.
- Android starter: app-private preferences hold profile configuration only. WebView cookies/cache remain app-wide; no per-profile isolation claim.
- Delete: close active session first, confirm with the user, then remove only that profile's data.
- Backup/export: exclude secrets by default; require explicit confirmation for any sensitive export.

## Security and privacy
- No CAPTCHA bypass, anti-bot evasion, credential harvesting, or claim of being undetectable.
- User-Agent, locale, timezone and viewport are configuration values, not proof of a unique fingerprint.
- Proxy and IP checks are diagnostics; IP geolocation is approximate and DNS/WebRTC checks are not exhaustive.
- Use a restrictive Electron preload/IPC boundary; renderer must not have Node integration.
- Keep browser engine updates current and review dependencies before release.

## Delivery phases
1. Foundation: shared schema, accurate platform capability labels, build reproducibility.
2. Profile lifecycle: create/edit/clone/delete, persistence and migration tests.
3. Windows isolation: verify cookies/local storage/cache separation with automated tests.
4. Android engine research: choose a supported engine and prove independent data stores before UI claims isolation.
5. Proxy diagnostics: per-profile proxy settings and observable connection tests, with credentials in secure storage.
6. Security review, signed release builds and platform-specific installers.

## Acceptance tests
- Create two profiles; verify unique IDs and storage keys.
- Windows: set a test cookie in profile A and verify it is absent in profile B after relaunch.
- Delete profile A and verify profile B data is unchanged.
- Android: verify UI clearly labels current WebView storage as shared; do not pass an isolation test until the engine supports it.
- Ensure exported diagnostics never contain proxy passwords.
