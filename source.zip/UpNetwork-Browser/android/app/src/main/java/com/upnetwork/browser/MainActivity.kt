package com.upnetwork.browser

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.content.Intent

class MainActivity : Activity() {
    private lateinit var store: ProfileStore
    private lateinit var list: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); store=ProfileStore(this); render() }
    private fun render() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,28,20,20);setBackgroundColor(0xff101827.toInt())}
        root.addView(TextView(this).apply{text="UpNetwork Browser";textSize=25f;setTextColor(-1);typeface=Typeface.DEFAULT_BOLD})
        root.addView(TextView(this).apply{text="Chromium-based Android profile manager";setTextColor(0xffb7c4d9.toInt());textSize=13f})
        val create=Button(this).apply{text="＋ Create Profile";setOnClickListener{editor(null)}}
        root.addView(create)
        val scroll=ScrollView(this);list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); refresh()
    }
    private fun refresh() {
        list.removeAllViews()
        store.all().forEach { p ->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,12,12,12);setBackgroundColor(0xff1d2a40.toInt())}
            card.addView(TextView(this).apply{text=p.name;setTextColor(-1);textSize=18f})
            card.addView(TextView(this).apply{text="Proxy: ${p.proxy.ifBlank{"Direct"}} · ${p.locale} · ${p.timezone}";setTextColor(0xffb7c4d9.toInt())})
            val row=LinearLayout(this)
            row.addView(Button(this).apply{text="Check & Open";setOnClickListener{val i=Intent(this@MainActivity,BrowserActivity::class.java);i.putExtra("profileId",p.id);startActivity(i)}})
            row.addView(Button(this).apply{text="Edit";setOnClickListener{editor(p)}})
            row.addView(Button(this).apply{text="Delete";setOnClickListener{store.delete(p.id);refresh()}})
            card.addView(row);list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,12,0,0)})
        }
    }
    private fun editor(old:BrowserProfile?) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun field(hint:String,value:String=""):EditText { val e=EditText(this);e.hint=hint;e.setText(value);box.addView(e);return e }
        val name=field("Profile name",old?.name?:"")
        val ua=field("Custom User-Agent (optional)",old?.userAgent?:"")
        val proxy=field("Proxy URL (support depends on Android WebView)",old?.proxy?:"")
        val locale=field("Locale",old?.locale?:"en-US")
        val tz=field("Timezone",old?.timezone?:"UTC")
        val dialog=android.app.AlertDialog.Builder(this).setTitle(if(old==null)"Create profile" else "Edit profile")
            .setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create()
        dialog.setOnShowListener { dialog.getButton(-1).setOnClickListener {
            if(name.text.isNullOrBlank()){name.error="Required";return@setOnClickListener}
            store.save(BrowserProfile(old?.id?:java.util.UUID.randomUUID().toString(),name.text.toString(),ua.text.toString(),proxy.text.toString(),locale.text.toString(),tz.text.toString()))
            dialog.dismiss();refresh()
        }}
        dialog.show()
    }
}
