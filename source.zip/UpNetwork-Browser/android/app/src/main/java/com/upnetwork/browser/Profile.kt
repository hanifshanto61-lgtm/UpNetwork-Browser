package com.upnetwork.browser

import org.json.JSONObject
import java.util.UUID

data class BrowserProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val userAgent: String = "",
    val proxy: String = "",
    val locale: String = "en-US",
    val timezone: String = "UTC"
) {
    fun json() = JSONObject().put("id",id).put("name",name).put("userAgent",userAgent)
        .put("proxy",proxy).put("locale",locale).put("timezone",timezone)
    companion object {
        fun from(j: JSONObject) = BrowserProfile(
            j.optString("id",UUID.randomUUID().toString()),j.optString("name","Profile"),
            j.optString("userAgent"),j.optString("proxy"),j.optString("locale","en-US"),j.optString("timezone","UTC"))
    }
}
