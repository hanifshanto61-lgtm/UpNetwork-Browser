package com.upnetwork.browser

import android.content.Context
import org.json.JSONArray

class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("upnetwork_profiles", Context.MODE_PRIVATE)
    fun all(): MutableList<BrowserProfile> {
        val a=JSONArray(prefs.getString("items","[]")); val out=mutableListOf<BrowserProfile>()
        for(i in 0 until a.length()) out.add(BrowserProfile.from(a.getJSONObject(i)))
        return out
    }
    fun save(p: BrowserProfile) {
        val list=all(); val i=list.indexOfFirst{it.id==p.id}
        if(i>=0) list[i]=p else list.add(p)
        val a=JSONArray(); list.forEach{a.put(it.json())}; prefs.edit().putString("items",a.toString()).apply()
    }
    fun delete(id:String) {
        val a=JSONArray(); all().filter{it.id!=id}.forEach{a.put(it.json())}
        prefs.edit().putString("items",a.toString()).apply()
    }
}
