package com.upnetwork.browser

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.widget.*
import android.view.ViewGroup
import android.graphics.Color
import org.json.JSONObject

class BrowserActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var report: TextView
    private lateinit var profile: BrowserProfile
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val id=intent.getStringExtra("profileId") ?: run{finish();return}
        profile=ProfileStore(this).all().firstOrNull{it.id==id} ?: run{finish();return}
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)}
        val bar=LinearLayout(this)
        val check=Button(this).apply{text="Run diagnostics";setOnClickListener{runChecks()}}
        val back=Button(this).apply{text="Back";setOnClickListener{finish()}}
        bar.addView(back);bar.addView(check);root.addView(bar)
        report=TextView(this).apply{setPadding(12,8,12,8);text="Pre-launch checks will run before browsing."}
        root.addView(report)
        web=WebView(this)
        web.settings.javaScriptEnabled=true
        web.settings.domStorageEnabled=true
        if(profile.userAgent.isNotBlank()) web.settings.userAgentString=profile.userAgent
        web.webViewClient=WebViewClient()
        root.addView(web,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
        runChecks()
    }
    private fun runChecks() {
        report.text="Checking network and browser configuration…"
        // The initial check uses the same WebView network stack. A proxy is not applied
        // unless the platform provides a supported proxy API; this build reports that.
        web.evaluateJavascript("(function(){return JSON.stringify({ua:navigator.userAgent,language:navigator.language,tz:Intl.DateTimeFormat().resolvedOptions().timeZone})})()") { }
        web.loadUrl("https://ipwho.is/")
        web.webViewClient=object:WebViewClient(){
            override fun onPageFinished(view:WebView,url:String) {
                if(url.contains("ipwho.is")) {
                    view.evaluateJavascript("(function(){try{return JSON.stringify(JSON.parse(document.body.innerText))}catch(e){return '{}'}})()") { raw ->
                        val clean=raw.trim('"').replace("\\\\\\"","\\"")
                        val obj=try{JSONObject(clean)}catch(_:Exception){JSONObject()}
                        val ok=obj.optBoolean("success",false)
                        val ip=obj.optString("ip","Unavailable")
                        val geo="${obj.optString("city","")}, ${obj.optString("country","")}"
                        val proxyNote=if(profile.proxy.isBlank())"No proxy configured." else "Proxy configured, but Android WebView proxy is not applied by this starter."
                        report.text=(if(ok)"WARNING — IP lookup succeeded" else "FAIL — IP lookup failed")+
                            "\\nIP: $ip\\nLocation: $geo\\n$proxyNote\\nAndroid WebView profile storage is app-wide, not isolated per profile."
                        if(ok) view.loadUrl("https://browserleaks.com/ip")
                    }
                }
            }
        }
    }
    override fun onDestroy(){ if(::web.isInitialized){web.stopLoading();web.destroy()};super.onDestroy() }
}
