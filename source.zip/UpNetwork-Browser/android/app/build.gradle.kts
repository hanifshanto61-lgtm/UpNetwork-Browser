plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.upnetwork.browser"
    compileSdk = 35
    defaultConfig { applicationId = "com.upnetwork.browser"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.2.0" }
}
