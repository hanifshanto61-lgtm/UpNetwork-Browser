# Test checklist

## Windows
- [ ] `npm install` completes.
- [ ] `npx playwright install chromium` completes.
- [ ] Create a direct-connection profile and run checks.
- [ ] Create a profile with an authorized HTTP or SOCKS5 proxy.
- [ ] Confirm the observed public IP is the proxy egress IP.
- [ ] Confirm configured UA / locale / timezone in report.
- [ ] Open two profiles and verify separate cookies/local storage.
- [ ] Close and reopen a profile; verify data persists.
- [ ] Delete a profile and confirm its profile directory is removed.
- [ ] Run `npm run dist:win` and test installer on a clean Windows VM.

## Android
- [ ] Gradle sync and build on Android Studio / JDK 17.
- [ ] Test on Android 8+ device with current System WebView.
- [ ] Confirm app clearly reports proxy is not applied by this starter.
- [ ] Confirm user-agent setting is reflected in navigator.userAgent.
- [ ] Verify no claim of isolated per-profile WebView storage is made.
