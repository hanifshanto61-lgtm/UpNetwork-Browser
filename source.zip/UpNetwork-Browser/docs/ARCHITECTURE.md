# Architecture

```text
UpNetwork Browser
├── Windows Desktop
│   ├── Electron UI
│   ├── Profile JSON store
│   ├── Playwright
│   └── Persistent Chromium context per profile
└── Android
    ├── Kotlin profile manager
    └── Android System WebView (Chromium provider)
```

## Windows profile lifecycle

1. Save a profile configuration.
2. Preflight launches a temporary headless persistent Chromium context using that profile's proxy and emulation settings.
3. It visits an IP metadata endpoint and reads the browser's observed environment.
4. FAIL blocks visible launch. WARNING permits launch only after the user reviews the report.
5. Visible launch creates the persistent profile context.

## Android architecture gap

Android WebView's data directory is process-wide. Its `setDataDirectorySuffix` must be called before WebView initialization and cannot be used to create an arbitrary new independent data directory for every profile inside one already-running process. The Android module therefore demonstrates configuration and diagnostics, not unlimited isolated profiles. A production Android implementation would need a custom Chromium/Content Shell build with a profile manager, or a documented finite process-slot design.

## Diagnostics are not certification

IP geo databases can be inaccurate. Browser locale/timezone checks report browser APIs, not every OS-level signal. DNS and WebRTC require dedicated tests under the actual profile. No report can guarantee account acceptance or undetectability.
