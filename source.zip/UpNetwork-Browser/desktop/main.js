const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

let win;
const sessions = new Map();
const storePath = () => path.join(app.getPath('userData'), 'profiles.json');
const profilesDir = () => path.join(app.getPath('userData'), 'profiles');

function readProfiles() {
  try { return JSON.parse(fs.readFileSync(storePath(), 'utf8')); }
  catch { return []; }
}
function writeProfiles(items) {
  fs.mkdirSync(path.dirname(storePath()), { recursive: true });
  fs.writeFileSync(storePath(), JSON.stringify(items, null, 2));
}
function safeId() { return 'profile-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,8); }
function publicProfile(p) {
  const { proxyPassword, ...safe } = p;
  return { ...safe, hasProxyPassword: !!proxyPassword };
}
function makeWindow() {
  win = new BrowserWindow({
    width: 1180, height: 820, minWidth: 900, minHeight: 640,
    backgroundColor: '#101522',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}
app.whenReady().then(() => {
  fs.mkdirSync(profilesDir(), {recursive:true});
  makeWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) makeWindow(); });
});
app.on('before-quit', async () => {
  for (const ctx of sessions.values()) { try { await ctx.close(); } catch {} }
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('profiles:list', () => readProfiles().map(publicProfile));
ipcMain.handle('profiles:create', (_, data) => {
  const items = readProfiles();
  const p = {
    id:safeId(), name:(data.name || 'New Profile').trim().slice(0,60),
    userAgent:(data.userAgent || '').trim(),
    proxyServer:(data.proxyServer || '').trim(),
    proxyUsername:(data.proxyUsername || '').trim(),
    proxyPassword:data.proxyPassword || '',
    locale:(data.locale || 'en-US').trim(),
    timezone:(data.timezone || 'UTC').trim(),
    width:Number(data.width)||1365, height:Number(data.height)||768,
    createdAt:new Date().toISOString()
  };
  items.push(p); writeProfiles(items); return publicProfile(p);
});
ipcMain.handle('profiles:update', (_, data) => {
  const items = readProfiles(); const i = items.findIndex(x=>x.id===data.id);
  if (i<0) throw new Error('Profile not found');
  const old=items[i];
  items[i]={...old, name:(data.name||old.name).trim().slice(0,60),
    userAgent:(data.userAgent??old.userAgent).trim(),
    proxyServer:(data.proxyServer??old.proxyServer).trim(),
    proxyUsername:(data.proxyUsername??old.proxyUsername).trim(),
    proxyPassword:data.proxyPassword===undefined?old.proxyPassword:data.proxyPassword,
    locale:(data.locale||old.locale).trim(), timezone:(data.timezone||old.timezone).trim(),
    width:Number(data.width)||old.width, height:Number(data.height)||old.height};
  writeProfiles(items); return publicProfile(items[i]);
});
ipcMain.handle('profiles:delete', async (_, id) => {
  if (sessions.has(id)) { try { await sessions.get(id).close(); } catch {} sessions.delete(id); }
  const items=readProfiles(); const p=items.find(x=>x.id===id);
  if (!p) return false;
  const answer=await dialog.showMessageBox(win,{type:'warning',buttons:['Cancel','Delete profile and local data'],defaultId:0,cancelId:0,
    message:`Delete "${p.name}" and its local browser data?`});
  if (answer.response!==1) return false;
  fs.rmSync(path.join(profilesDir(), id),{recursive:true,force:true});
  writeProfiles(items.filter(x=>x.id!==id)); return true;
});
function proxyOptions(p) {
  if (!p.proxyServer) return undefined;
  const out={server:p.proxyServer};
  if (p.proxyUsername) out.username=p.proxyUsername;
  if (p.proxyPassword) out.password=p.proxyPassword;
  return out;
}
async function launchContext(p, headless) {
  const options={
    headless, viewport:{width:p.width,height:p.height},
    locale:p.locale, timezoneId:p.timezone,
    userAgent:p.userAgent || undefined,
    proxy:proxyOptions(p),
    args:['--disable-blink-features=AutomationControlled']
  };
  return chromium.launchPersistentContext(path.join(profilesDir(),p.id),options);
}
ipcMain.handle('profiles:check', async (_, id) => {
  const p=readProfiles().find(x=>x.id===id); if(!p) throw new Error('Profile not found');
  let ctx;
  const report={profile:p.name,checkedAt:new Date().toISOString(),checks:[],status:'FAIL',observed:{}};
  const add=(name,status,detail)=>report.checks.push({name,status,detail});
  try {
    ctx=await launchContext(p,true);
    const page=ctx.pages()[0] || await ctx.newPage();
    const response=await page.goto('https://ipwho.is/',{waitUntil:'domcontentloaded',timeout:25000});
    if (!response || !response.ok()) throw new Error('IP lookup endpoint returned an error');
    const ip=await page.evaluate(()=>JSON.parse(document.body.innerText));
    if (!ip.success) throw new Error(ip.message || 'IP lookup failed');
    report.observed.ip=ip.ip; report.observed.country=ip.country; report.observed.region=ip.region; report.observed.city=ip.city;
    report.observed.isp=ip.connection?.isp || ''; report.observed.timezone=ip.timezone?.id || '';
    add('Proxy / internet connectivity','PASS',`Connected; public IP ${ip.ip}`);
    add('IP geolocation','PASS',[ip.city,ip.region,ip.country].filter(Boolean).join(', '));
    const ua=await page.evaluate(()=>navigator.userAgent);
    report.observed.userAgent=ua;
    add('User-Agent','PASS',p.userAgent ? (ua===p.userAgent?'Configured User-Agent observed':'Browser returned a different User-Agent') : 'Default Chromium User-Agent observed');
    const env=await page.evaluate(()=>({language:navigator.language,languages:navigator.languages,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone}));
    report.observed.language=env.language; report.observed.timezoneBrowser=env.timezone;
    add('Language','PASS',`Browser language: ${env.language}`);
    add('Timezone','PASS',`Browser timezone: ${env.timezone}`);
    if (p.timezone && env.timezone!==p.timezone) add('Timezone consistency','WARNING',`Configured ${p.timezone}; browser reports ${env.timezone}`);
    else add('Timezone consistency','PASS','Configured timezone matches browser report');
    if (ip.timezone?.id && env.timezone!==ip.timezone.id) add('IP / browser timezone match','WARNING',`IP timezone ${ip.timezone.id}; browser timezone ${env.timezone}`);
    else add('IP / browser timezone match','PASS','No mismatch detected by this check');
    add('DNS / WebRTC','WARNING','Not conclusively tested by this preflight. Run the diagnostic links inside the launched profile.');
    report.status=report.checks.some(x=>x.status==='FAIL')?'FAIL':report.checks.some(x=>x.status==='WARNING')?'WARNING':'PASS';
  } catch(e) {
    add('Pre-launch connectivity','FAIL',e.message || String(e));
    report.status='FAIL';
  } finally { if(ctx) try{await ctx.close()}catch{} }
  return report;
});
ipcMain.handle('profiles:launch', async (_, id) => {
  const p=readProfiles().find(x=>x.id===id); if(!p) throw new Error('Profile not found');
  if(sessions.has(id)) { const old=sessions.get(id); try { await old.pages()[0]?.bringToFront(); return true; } catch { sessions.delete(id); } }
  const ctx=await launchContext(p,false);
  sessions.set(id,ctx);
  ctx.on('close',()=>sessions.delete(id));
  const page=ctx.pages()[0] || await ctx.newPage();
  await page.goto('https://browserleaks.com/ip',{waitUntil:'domcontentloaded',timeout:30000}).catch(()=>{});
  return true;
});
ipcMain.handle('profiles:close', async (_, id) => {
  if(!sessions.has(id)) return true;
  await sessions.get(id).close(); sessions.delete(id); return true;
});
ipcMain.handle('app:version',()=>app.getVersion());
