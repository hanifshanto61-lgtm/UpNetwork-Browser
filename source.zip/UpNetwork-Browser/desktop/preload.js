const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('upnetwork', {
  list:()=>ipcRenderer.invoke('profiles:list'),
  create:data=>ipcRenderer.invoke('profiles:create',data),
  update:data=>ipcRenderer.invoke('profiles:update',data),
  remove:id=>ipcRenderer.invoke('profiles:delete',id),
  check:id=>ipcRenderer.invoke('profiles:check',id),
  launch:id=>ipcRenderer.invoke('profiles:launch',id),
  close:id=>ipcRenderer.invoke('profiles:close',id),
  version:()=>ipcRenderer.invoke('app:version')
});
