const $=id=>document.getElementById(id);
let reports=new Map();
function toast(s){$('toast').textContent=s;$('toast').style.display='block';setTimeout(()=>$('toast').style.display='none',3000)}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function render(){
 const ps=await window.upnetwork.list(); $('count').textContent=`${ps.length} profiles`;
 $('profiles').innerHTML=ps.length?ps.map(p=>`<article class="card"><h3>${esc(p.name)}</h3><div class="meta">ID: ${esc(p.id)}<br>Proxy: ${esc(p.proxyServer||'Direct connection')}<br>Locale: ${esc(p.locale)} · Timezone: ${esc(p.timezone)}<br>UA: ${esc(p.userAgent||'Chromium default')}</div><div class="buttons"><button class="check" data-check="${p.id}">Run checks</button><button class="launch" data-launch="${p.id}" ${reports.get(p.id)?.status==='FAIL'?'disabled':''}>Open Browser</button><button data-edit="${p.id}">Edit</button><button data-close="${p.id}">Close</button><button data-delete="${p.id}">Delete</button></div><div class="meta" id="status-${p.id}">${reports.has(p.id)?`Last check: <b class="${reports.get(p.id).status}">${reports.get(p.id).status}</b>`:'Not checked yet'}</div></article>`).join(''):`<div class="card"><h3>No profiles yet</h3><p>Create your first browser profile to get started.</p></div>`;
}
function values(){return {id:$('id').value,name:$('name').value,userAgent:$('ua').value,proxyServer:$('proxy').value,proxyUsername:$('proxyUser').value,proxyPassword:$('proxyPass').value,locale:$('locale').value,timezone:$('timezone').value,width:$('width').value,height:$('height').value}}
function openEditor(p){
 $('profileForm').reset();$('id').value=p?.id||'';$('formTitle').textContent=p?'Edit profile':'Create profile';
 $('name').value=p?.name||'';$('ua').value=p?.userAgent||'';$('proxy').value=p?.proxyServer||'';
 $('proxyUser').value=p?.proxyUsername||'';$('proxyPass').value='';$('locale').value=p?.locale||'en-US';$('timezone').value=p?.timezone||'UTC';
 $('width').value=p?.width||1365;$('height').value=p?.height||768;$('editor').showModal();
}
$('new').onclick=()=>openEditor();
$('profileForm').onsubmit=async e=>{e.preventDefault();try{const d=values();if(d.id)await window.upnetwork.update(d);else await window.upnetwork.create(d);$('editor').close();toast('Profile saved');render()}catch(e){toast(e.message)}};
$('closeReport').onclick=()=>$('report').close();
function showReport(r,id){
 reports.set(id,r);$('reportBody').innerHTML=`<p>Profile: <b>${esc(r.profile)}</b></p><p>Overall status: <span class="status ${r.status}">${r.status}</span></p><p class="meta">Checked: ${esc(r.checkedAt)}</p>${r.observed.ip?`<p class="meta">IP: ${esc(r.observed.ip)} · ${esc(r.observed.city||'')}, ${esc(r.observed.country||'')} · ISP: ${esc(r.observed.isp||'')}</p>`:''}${r.checks.map(c=>`<div class="checkrow"><b class="${c.status}">${c.status}</b> — ${esc(c.name)}<p>${esc(c.detail)}</p></div>`).join('')}<p class="meta">A WARNING is not a verified clean fingerprint. Review the details before proceeding.</p>`;
 $('report').showModal();render();
}
$('profiles').onclick=async e=>{
 const b=e.target.closest('button');if(!b)return;const id=b.dataset.check||b.dataset.launch||b.dataset.edit||b.dataset.close||b.dataset.delete;
 try{
 if(b.dataset.check){b.disabled=true;b.textContent='Checking…';const r=await window.upnetwork.check(id);showReport(r,id)}
 if(b.dataset.launch){const r=reports.get(id);if(!r){toast('Run checks before opening this profile');return}if(r.status==='FAIL'){toast('Launch blocked: required check failed');return}await window.upnetwork.launch(id);toast('Browser profile launched')}
 if(b.dataset.edit){const p=(await window.upnetwork.list()).find(x=>x.id===id);openEditor(p)}
 if(b.dataset.close){await window.upnetwork.close(id);toast('Profile closed')}
 if(b.dataset.delete){if(await window.upnetwork.remove(id)){reports.delete(id);toast('Profile and local data deleted')}}
 }catch(err){toast(err.message||String(err))}finally{render()}
};
render();
